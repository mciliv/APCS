package pacWorld;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class PacCritter extends Critter
{

	public PacCritter()
	{
		super();
	}

	public ArrayList<Actor> getActors()
	{
		ArrayList<Actor> theActors = new ArrayList<Actor>();
		if ((getGrid().get(getLocation().getAdjacentLocation(getDirection()))) instanceof Pellet)
		{
			theActors.add((getGrid().get(getLocation().getAdjacentLocation(getDirection()))));
		}
		
		theActors.add((getGrid().get(new Location(0,10))));
		return theActors;
	}
	
	public void processActors(ArrayList<Actor> actors)
	{
		if (actors.size()==2)
		{
			GameKeeper gameKeeper = (GameKeeper) actors.get(1);
			gameKeeper.setScore(gameKeeper.getScore() + 1);
		}
	}

	//	public ArrayList<Location> getMoveLocations()
	//	{
	//		Grid<Actor> grid = getGrid();
	//		ArrayList<Location> validLocs = grid.getValidAdjacentLocations(getLocation());
	//		ArrayList<Location> locs = new ArrayList<Location>();
	//		for (int i = 0; i<validLocs.size(); i++)
	//		{
	//			if (!(grid.get(validLocs.get(i)) instanceof Rock))
	//			{
	//				locs.add(validLocs.get(i));
	//			}
	//		}
	//		return validLocs;
	//	}

	public Location selectMoveLocation(ArrayList<Location> locs)
	{
		if (getGrid().get(getLocation().getAdjacentLocation(getDirection())) instanceof Rock)
		{
			return getLocation();
		}
		return getLocation().getAdjacentLocation(getDirection());
	}
}
