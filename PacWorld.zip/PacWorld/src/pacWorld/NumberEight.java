package pacWorld;

import info.gridworld.actor.Flower;

public class NumberEight extends Flower
{
    public void act()
    {
        // Override Flower's act() with an empty act(), so that
        // the color doesn't darken
    }

}
